import React, { useState } from 'react';
import './style.css';
// import Button from './Button'

const App = () =>{

    let [score,setScore] = useState(0);

    return(
        <div style={{textAlign:"center"}}>
            <h1>Counter Apllication</h1>
            <p>the value of score is {score}</p>
            <div>
                <button className="btn" onClick={()=>(score<25)? setScore(score+1) : ''} >Increment</button>
                <button className="btn" onClick={()=>(score>0)? setScore(score-1) : ''} >Decrement</button>
                <button className="btn" onClick={()=>{setScore(0)}} >Reset</button> 
               {/* <Button ButtonText="Go" ButtonClass="btn go" />
                <Button ButtonText="Reset" ButtonClass="btn reset" />
                <Button ButtonText="Cancel" ButtonClass="btn cancel" /> */}
                
            </div>
        </div>
    )

}


export default App;