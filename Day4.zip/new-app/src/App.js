import React, {useState} from 'react'
import Icon from "./Components/Icon"
// import react-toastify
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
// import reactstrap
import { Button,Container, Card, CardBody, Row, Col, Input } from 'reactstrap';
import 'bootstrap/dist/css/bootstrap.css';
import "./style.css"


const tiktacArray = new Array(9).fill("")
const App = () => {
    let [isCross, setIsCross] = useState(true)
    let [winMessage, setWinMessage] = useState("")
    let [ischeck, setIscheck] = useState(false)
    const playAgain=()=>{
        // setIsCross(true);
        document.querySelector('input[type=radio]:checked').checked = false;
        
        setIscheck(false);
        setWinMessage("")
        tiktacArray.fill("")
        // console.log("Hello")
    }

   
    const findWinner=()=>{
        if(tiktacArray[0]== tiktacArray[1] && tiktacArray[0]==tiktacArray[2] && tiktacArray[0]!=""){
           setWinMessage(tiktacArray[0]+" has won")
        }
        else if(tiktacArray[3]== tiktacArray[4] && tiktacArray[3]==tiktacArray[5] && tiktacArray[3]!=""){
            setWinMessage(tiktacArray[3]+" has won")
        }
        else if(tiktacArray[6]== tiktacArray[7] && tiktacArray[6]==tiktacArray[8] && tiktacArray[6]!=""){
            setWinMessage(tiktacArray[6]+" has won")
        }
        else if(tiktacArray[0]== tiktacArray[3] && tiktacArray[0]==tiktacArray[6] && tiktacArray[0]){
            setWinMessage(tiktacArray[0]+" has won")
        }
        else if(tiktacArray[1]== tiktacArray[4] && tiktacArray[1]==tiktacArray[7] && tiktacArray[1]){
            setWinMessage(tiktacArray[1]+" has won")
        }
        else if(tiktacArray[2]== tiktacArray[5] && tiktacArray[2]==tiktacArray[8] && tiktacArray[2]){
            setWinMessage(tiktacArray[2]+" has won")
        }
        else if(tiktacArray[2]== tiktacArray[4] && tiktacArray[2]==tiktacArray[6] && tiktacArray[2]){
            setWinMessage(tiktacArray[2]+" has won")
        }
        else if(tiktacArray[0]== tiktacArray[4] && tiktacArray[0]==tiktacArray[8] && tiktacArray[0]){
            setWinMessage(tiktacArray[0]+" has won")
        }

    }

    const changeItem = (index)=>{
        if(ischeck == true){
            if(winMessage){
                return toast("Game has already got over", {type: "success"})
            }
            if(tiktacArray[index] =="" ){
                tiktacArray[index] = isCross ? "cross" : "circle"
                setIsCross(!isCross)
            }
            else{
                return toast("Open your eyes dude where are you tapping", {type: "error"})
            }
            findWinner()
        }
        else{
            return toast("Select your choice i.e Cross or Circle", {type: "error"})
        }
    }


 const handleChange = (event) => {
    let val = event.target.value
    
    if(val == "Cross"){
        setIsCross(true)
    }else{
        setIsCross(false)
    }
    setIscheck(true)
    document.getElementById('heading').style.display = 'block';
  }
  
  

    return(
         <Container className="p-5"> 
           <ToastContainer position="bottom-center" > </ToastContainer>
            <Row> 
               <Col md={6} className="offset-md-3"> 
                <div style={{textAlign:"center"}}> 
                  <label> 
                    <input type="radio" value="Cross" name="gametype" onChange={handleChange} />Cross
                  </label>
                    &nbsp; &nbsp; &nbsp; &nbsp; 
                  <label> 
                    <input type="radio" value="Circle" name="gametype" onChange={handleChange} />   Circle
                  </label>
                </div>
                  {
                    winMessage? (
                        <div className="header-section">
                            <h1 className="text-center"> 
                            {winMessage}
                            </h1>
                            <Button onClick={playAgain}> Play Again</Button>
                        </div>
                    ) : (
                        <div className="header-section" >
                            
                            <h1 style={{textAlign : "center",display:"none"}} id="heading">
                                {isCross? "Cross's Turn": "Circle's Turn"}
                            </h1>
                        </div>
                    )
                  } 

                 <div className="grid"> 
                       {tiktacArray.map((value,index)=>(
                           <Card onClick={()=>changeItem(index)}> 
                               <CardBody className="box"> 
                                   <Icon choice={tiktacArray[index]}/>
                               </CardBody>
                           </Card>
                       ))}

                  </div>
                </Col>

            </Row>
             
         </Container>
    )
}

export default App



 