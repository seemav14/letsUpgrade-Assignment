import React from 'react';
import './style.css';
import Button from './Button'

const App = () =>{
    return(
        <div style={{textAlign:"center"}}>
            <h1>Hello React</h1>
            <p>My First React Project</p>
            <div>
                {/* <button className="btn">Go</button>
                <button className="btn">Reset</button>
                <button className="btn">Cancel</button> */}
                <Button ButtonText="Go" ButtonClass="btn go" />
                <Button ButtonText="Reset" ButtonClass="btn reset" />
                <Button ButtonText="Cancel" ButtonClass="btn cancel" />

            </div>
        </div>
    )

}


export default App;